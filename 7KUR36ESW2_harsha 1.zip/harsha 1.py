# 1
a="Python"
print(a[0],a[5],len(a))

# 2
a="Deepak"
print(a[0],a[5],len(a),sep="\n")

# 3
a="Hi"
print(a*3)

# 4
a="Good"
b="Morning"
print(a+b)

# 5
a="Programming"
print(a[0],a[3],a[-1],sep="\n")

# 6
a="Chennai"
print(a[0],a[6],len(a),sep="\n")

# 7
a="Py"
b="thon"
c=a+b
print(c,len(c),sep="\n")

# 8
a="*"
print(a*5)

# 9
a="Ravi"
b="Madurai"
print(a,",",b,",",len(a),",",len(b))

# 10
a="Python"
print(a*2,a[0],a[5],len(a),sep="\n")